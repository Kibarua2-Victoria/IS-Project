<?php

namespace App\Http\Controllers;
use App\Sample_data; //calls the model
use App\Http\Requests;
use Session;


class Sample_dataController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $sample_data=Sample_data::paginate(5);
        return view('sample_data.index')->withSample_data($sample_data);
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    
public function create()
    {
        return view('sample_data.create');
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //validate the database
        $request->validate([
            'first_name'=>'required',
            'NHIF_number'=>'required',
            'image'=>'required|image|max:2048'
        ]);
        //store in the database
        $sample_data=new Sample_data;
        $sample_data->first_name=$request->first_name;
        $sample_data->NHIF_number=$request->NHIF_number;
        $sample_data->image=$request->image;

        $sample_data->save();

        Session::flash('success','Data successfully saved');

        //redirect to another page
        return redirect()->route('sample_data.show',$sample_data->id);

}

    



    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $sample_data=Sample_data::find($id);
        return view('sample_data.show')->withSample_data($sample_data);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $sample_data=Sample_data::find($id);
        return view('sample_data.edit')->withSample($sample_data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
            $request->validate([
                'first_name'=>'required',
                'NHIF_number'=>'required',
                'image'=>'image|max:2048'
            ]);
    if($request->hasfile('image'))
    {
    $file=$request->file('image');
    $extension=$file->getClientOriginalExtension(); //getting image extension
    $filename=time().'.'.$extension;
    $file->move('uploads/sample_data/',$filename);
     $Admin->image=$filename;
    }
           
            if($Admin->save());
            {
                return redirect('crud')->with('msg','Data is Successfully updated');
        }
    
      return back()->with('msg','Please choose image');         
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        
    }
}

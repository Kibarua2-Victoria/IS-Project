<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-12">
    <h1>About Us</h1>
    <p>We value integrity and transparency</p>
  </div>
</div>

 <?php $__env->stopSection(); ?> 

    
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new_project\resources\views/about.blade.php ENDPATH**/ ?>
 <!--inheritance from parents.blade.php -->

<?php $__env->startSection('main'); ?> <!--defines a section of the parent.balde to php file-->

<div align="right">
	<a href="<?php echo e(url('Admin/create')); ?>" class="btn btn-success btn-sm">Add</a>
</div>	
<?php if($message=Session::get('success')): ?>
<div class="alert alert-success">
	<p><?php echo e($message); ?></p>
</div>
<?php endif; ?>

		<table class="table table-bordered table-striped">
			<tr>
				<th width="10%">Image</th>
				<th width="35%">First Name</th>
				<th width="35%">NHIF Number</th>
				<th width="35%">Action</th>
			</tr>
			<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><img src="<?php echo e(asset('uploads/Admin/' . $row->image)); ?>" width="100px" height="100px" /></td>
				<td><?php echo e($row->first_name); ?></td>
				<td><?php echo e($row->NHIF_number); ?></td>
				<td>
					<a href="<?php echo e(route('Admin.show',$row->id)); ?>" class="btn btn-primary">Show</a>
					<a href="<?php echo e(route('Admin.edit',$row->id)); ?>" class="btn btn-warning">Edit</a>

				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</table>
<?php echo $data->links(); ?> <!--makes pagination link-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.parent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new_project\resources\views/Admin/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', '|Create New Post'); ?>

<?php $__env->startSection('content'); ?>

	<div class="row">
		<div class="col-md-8 col-md-offset-2">
			<h1>Fill In The Details</h1>
			
			<hr>
	</div>
	</div>
	<div class="form-group">
		<label class="col-md-4 text-left">Enter First Name</label>
		<div class="col-md-8">
			<input type="text" name="first_name" class="form-control" placeholder="Enter First Name"/>
		</div>
	</div>
	<br/></br></br>
	<div  class="form-group">
	<label class="col-md-4 text-left">Enter NHIF number<label/>
		<div class="col-md-8">
		<input type="NHIF number" name="NHIF number" class="form-control" placeholder="Enter NHIF Number" >
		</div>
	</div>
		<label>Select Profile Image</label>
		<input type="file" name="image">

	<br/></br></br>
	<div class="form-group text-center">
		<input type="submit" name="add" class="btn btn-success btn-lg btn-block" value="Add"/>
	</div>



</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new_project\resources\views/Admin/create.blade.php ENDPATH**/ ?>
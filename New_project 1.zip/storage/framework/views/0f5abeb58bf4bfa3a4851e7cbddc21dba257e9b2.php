<?php $__env->startSection('title'); ?>

<?php $__env->startSection('content'); ?>
	
	<div class="jumbotron text-center">
		<div align="right">
			<a href="<?php echo e(route('sample_data.create')); ?>" class="btn btn-default">Back</a>
		</div>
<br/><br/>
		<?php $__currentLoopData = $sample_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sample_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<th><?php echo e($sample_data->id); ?>

					</th>
					<td><?php echo e($sample_data->first_name); ?>

					</td>

					<td><?php echo e($sample_data->NHIF_number); ?>

					</td>
					<td><?php echo e($sample_data->image); ?>

					</td>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new_project\resources\views/sample_data/show.blade.php ENDPATH**/ ?>
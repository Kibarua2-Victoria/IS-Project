<?php $__env->startSection('title'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-md-10">
		<h1>Details</h1>
	</div>

	<div class="col-md-2">
		<a href="<?php echo e(route('sample_data.create')); ?>" class="btn btn-lg btn-block btn-primary btn-h1-spacing">Create Details</a>
	</div>
	<div class="col-md-12">
		<hr>
	</div>
</div>

<div class="row">
	<div class="col-md-8">
		<table class="table">
			<thead>
				<th>#</th>
				<th>First Name</th>
				<th>NHIF Number</th>
				<th>Image</th>
			</thead>

			<tbody>
				<?php $__currentLoopData = $sampleData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sample_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<th><?php echo e($sample_data ->id); ?>

					</th>
					<td><?php echo e($sample_data->first_name); ?>

					</td>

					<td><?php echo e($sample_data->NHIF_number); ?>

					</td>
					<td><?php echo e($sample_data->image); ?>

					</td>

					<td><a href="<?php echo e(route('sample_data.show',$sample_data ?? ''->id)); ?>" class="btn btn-default btn-sm">View</a></td>
					<td><a href="<?php echo e(route('sample_data.edit',$sample_data ?? ''->id)); ?>" class="btn btn-default btn-sm">Edit</a></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
		<div class="text-center">
		
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new_project\resources\views/sample_data/index.blade.php ENDPATH**/ ?>
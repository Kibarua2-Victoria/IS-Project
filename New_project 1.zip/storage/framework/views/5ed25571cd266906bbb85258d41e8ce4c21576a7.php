<title>Registration Form</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

<?php echo $__env->yieldContent('stylesheets'); ?><?php /**PATH C:\xampp\htdocs\new_project\resources\views/partials/_head.blade.php ENDPATH**/ ?>
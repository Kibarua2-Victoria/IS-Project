<?php $__env->startSection('title'); ?>

<?php $__env->startSection('content'); ?>
	
	<div class="jumbotron text-center">
		<div align="right">
			<a href="<?php echo e(route('posts.create')); ?>" class="btn btn-default">Back</a>
		</div>
	<br/>
		<img src="<?php echo e(asset('../public/uploads/posts/' . $errors->image)); ?>" width=(100px) height=(100px) alt="image"/>
		<h3>First Name-<?php echo e($data->first_name); ?></h3>
		<h3>NHIF Number-<?php echo e($data->NHIF_number); ?></h3>
	</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new_project\resources\views/posts/view.blade.php ENDPATH**/ ?>
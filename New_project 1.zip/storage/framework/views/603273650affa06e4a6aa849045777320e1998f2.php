<?php $__env->startSection('main'); ?>
	
	<div class="jumbotron text-center">
		<div align="right">
			<a href="<?php echo e(route('Admin.index')); ?>" class="btn btn-default">Back</a>
		</div>
	<br/>
		<img src="<?php echo e(asset('uploads/Admin/' . $errors->image)); ?>" width=(100px) height=(100px) alt="image"/>
		<h3>First Name-<?php echo e($data->first_name); ?></h3>
		<h3>NHIF Number-<?php echo e($data->NHIF_number); ?></h3>
	</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.parent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new_project\resources\views/Admin/view.blade.php ENDPATH**/ ?>
<?php $__env->startSection('main'); ?>

<div align="right">
	<a href="<?php echo e(route('Admin.index')); ?>" class="btn btn-default">Back</a>
</div>
<br/>

<form method="post" action="<?php echo e(route('Admin.update',$data->id)); ?>" enctype="multipart/form-data">

	<?php echo csrf_field(); ?>
	<?php echo method_field('PATCH'); ?> <!--is a method used to as a template for the fill form-->
	<div class="form-group">
		<label class="col-md-4  text-left">Enter First Name</label>
		<div class="col-md-8">
			<input type="text" name="first_name" value="<?php echo e($Admin ?? ''); ?>" class="form-control" placeholder="Enter First Name"/>
		</div>
	</div>
</br></br>
	
	<div  class="form-group">
	<label class="col-md-4 text-left">Enter NHIF number<label/>
		<div class="col-md-8">
		<input type="NHIF number" name="NHIF number" class="form-control" placeholder="Enter NHIF Number" >
		</div>
	</div>
</br></br>
	<label>Select Profile Image</label>
		<input type="file" name="image">
</br></br>
	<div class="form-group text-center">
		<input type="submit" name="edit" class="btn btn-primary input-lg" value="Edit"/>
	</div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.parent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new_project\resources\views/Admin/edit.blade.php ENDPATH**/ ?>
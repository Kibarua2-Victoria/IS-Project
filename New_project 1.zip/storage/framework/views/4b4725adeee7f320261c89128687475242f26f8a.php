<?php $__env->startSection('title'); ?>

<?php $__env->startSection('stylesheets'); ?>

	<?php echo Html::style('css/parsley.css'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<div class="row">
	<div class="col-md-8 col-md-offset-2">
		<h1>Enter Details</h1>
		<hr>
</div>
</div>
	<?php echo Form::open(array('route' => 'posts.store','data-parsley-validate'=>'','files'=>true)); ?>

    	  	
		<?php echo e(Form::label('first_name'),('First Name')); ?>

		<?php echo e(Form::text('First Name',null,array('class'=>'form-control','required'))); ?>


		<?php echo e(Form::label('NHIF_number'),('NHIF Number')); ?>

		<?php echo e(Form::text('NHIF Number',null,array('class'=>'form-control','required'))); ?>

    	
		<?php echo e(Form::label('featured_image','Upload Featured Image')); ?>

    	<?php echo e(Form::file('featured_image')); ?>


    	<?php echo e(Form::submit('Create',array('class'=>'btn btn-success btn-lg btn-block','style'=>'margin-top:20px;'))); ?>

	<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new_project\resources\views/posts/create.blade.php ENDPATH**/ ?>
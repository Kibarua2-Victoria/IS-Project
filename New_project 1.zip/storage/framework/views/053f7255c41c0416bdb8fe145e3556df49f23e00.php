<?php $__env->startSection('title'); ?>

<?php $__env->startSection('content'); ?>
<div align="right">
	<a href="<?php echo e(url('sample_data/view')); ?>" class="btn btn-default">Back</a>
</div>
<br/>



	<?php echo csrf_field(); ?>
	<?php echo method_field('PATCH'); ?> <!--is a method used to as a template for the fill form-->
	
	<?php echo Form::open(array('route' => 'sample_data.update','data-parsley-validate'=>'','files'=>true)); ?>

    	  	
		<?php echo e(Form::label('first_name'),('First Name')); ?>

		<?php echo e(Form::text('First Name',null,array('class'=>'form-control','required'))); ?>


		<?php echo e(Form::label('NHIF_number'),('NHIF Number')); ?>

		<?php echo e(Form::text('NHIF Number',null,array('class'=>'form-control','required'))); ?>

    	
		<?php echo e(Form::label('featured_image','Upload Featured Image')); ?>

    	<?php echo e(Form::file('featured_image')); ?>


    	<?php echo e(Form::submit('create',array('class'=>'btn btn-success btn-lg btn-block','style'=>'margin-top:20px;'))); ?>

	<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new_project\resources\views/sample_data/edit.blade.php ENDPATH**/ ?>
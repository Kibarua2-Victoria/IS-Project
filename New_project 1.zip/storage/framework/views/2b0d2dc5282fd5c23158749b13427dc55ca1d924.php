<?php $__env->startSection('title'); ?>

<?php $__env->startSection('content'); ?>
	
	<div class="jumbotron text-center">
		<div align="right">
			<a href="<?php echo e(route('posts.create')); ?>" class="btn btn-default">Back</a>
		</div>
<br/><br/>
		<?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<th><?php echo e($post->id); ?>

					</th>
					<td><?php echo e($post->first_name); ?>

					</td>

					<td><?php echo e($post->NHIF_number); ?>

					</td>
					<td><?php echo e($post->image); ?>

					</td>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new_project\resources\views/posts/show.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-md-12">
                <h1>Contact Us</h1>
                <hr>
                <form>
                    <div class="form-group">
                        <label name="subject">Subject</label>
                        <input type="text" name="subject" class="form-control">
                    </div>

                    <div class="form-group">
                        <label name="Message">Message</label>
                        <input type="text" name="subject" class="form-control">
                    </div>

                    <input type="submit" name="Send" class="btn btn-success">
                </form>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new_project\resources\views/contact.blade.php ENDPATH**/ ?>
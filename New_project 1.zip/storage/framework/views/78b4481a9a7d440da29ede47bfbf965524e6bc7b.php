	<link rel="stylesheet" type="text/css" href="header.php">
	<div class="container">
	<form class="form-horizontal" method="POST" action="<?php echo e(url('/new_project')); ?>">
		<?php echo e(csrf_field()); ?>


	  	<legend>Registration Form</legend>
	  	<?php if(count($errors)>0): ?>
	  		<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	  			<div class="co-md-8 alert alert-danger"><?php echo e($error); ?></div>
	  		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  	<?php endif; ?>

	  	<?php if(session('response')): ?>
	  		<div class="col-md-8 alert alert-success"><?php echo e(session('Success')); ?></div>
	  	<?php endif; ?>
	  	<div class="form-group">
	      <label for="inputFirstName" class="col-lg-2 control-label">First Name</label>
	      <div class="col-lg-6">
	        <input type="text" name="fname" class="form-control" id="inputFirstName" placeholder="required">
	      </div>
	  </div>

	  <div class="form-group">
	  <label for="inputUsername" class="col-lg-2 control-label">Username</label>
	      <div class="col-lg-6">
	        <input type="text" name="username" class="form-control" id="inputUsername" placeholder="Username">
	      </div>
	  </div>

	  <div class="form-group">
	  <label for="inputEmail" class="col-lg-2 control-label">Email</label>
	      <div class="col-lg-6">
	        <input type="text" name="email" class="form-control" id="inputEmail" placeholder="Email">
	      </div>
	  </div>

	  <div class="form-group">
	  <label for="inputPassword" class="col-lg-2 control-label">Password</label>
	      <div class="col-lg-6">
	        <input type="password" name="password" class="form-control" id="inputPassword" placeholder="Password">
	      </div>
	  </div>

	  <div class="form-group">
	  <label for="inputPassword" class="col-lg-2 control-label"> Confirm Password</label>
	      <div class="col-lg-6">
	        <input type="password" name="passconf" class="form-control" id="inputPassword" placeholder="Confirm password"><p>never share your password with anyone.</p>
	      </div>
	  </div>

      <div class="form-group">
        <label class="col-lg-2 control-label">Rank</label>
        <div class="col-lg-10">
        <div class="radio">
        <label> 
         <input type="radio" name="rank" id="optionsRadios1" value="Hospital Admin"> 
         Hospital Admin
        </label>
      	</div>
      </div>
  </div>
      	<div class="radio">
        <label> 
         <input type="radio" name="rank" id="optionsRadios2" value="NHIF Admin">
         NHIF Admin
        </label>
      	</div>
      	<button type="submit" class="btn btn-primary">Submit</button>
	   <button type="cancel" class="btn btn-primary">Cancel</button>
</div>
</form>
<?php /**PATH C:\xampp\htdocs\new_project\resources\views/HOME.blade.php ENDPATH**/ ?>
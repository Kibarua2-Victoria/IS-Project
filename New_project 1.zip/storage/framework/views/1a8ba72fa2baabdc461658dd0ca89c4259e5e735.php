<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<title>ADMINISTRATOR</title>
	<meta content='width=device-width,initial-scale=1,maximum-scale=1' name='viewport'/>
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" ></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
	<div class="container">
	<br/>
	<h3 align="center">NHIF ADMINISTRATOR</h3>
	<br/>
	<?php echo $__env->yieldContent('main'); ?>
	</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\new_project\resources\views/Admin/parent.blade.php ENDPATH**/ ?>
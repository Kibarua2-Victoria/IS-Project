@extends('main')

@section('title')

@section('content')
	
	<div class="jumbotron text-center">
		<div align="right">
			<a href="{{route('sample_data.create')}}" class="btn btn-default">Back</a>
		</div>
<br/><br/>
		@foreach($sample_data as $sample_data)
				<tr>
					<th>{{$sample_data->id}}
					</th>
					<td>{{$sample_data->first_name }}
					</td>

					<td>{{$sample_data->NHIF_number}}
					</td>
					<td>{{$sample_data->image}}
					</td>
		@endforeach
	</div>


@endsection
@extends('main')

@section('title')

@section('content')
<div align="right">
	<a href="{{url('sample_data/view')}}" class="btn btn-default">Back</a>
</div>
<br/>



	@csrf
	@method('PATCH') <!--is a method used to as a template for the fill form-->
	
	{!! Form::open(array('route' => 'sample_data.update','data-parsley-validate'=>'','files'=>true)) !!}
    	  	
		{{Form::label('first_name'),('First Name')}}
		{{Form::text('First Name',null,array('class'=>'form-control','required'))}}

		{{Form::label('NHIF_number'),('NHIF Number')}}
		{{Form::text('NHIF Number',null,array('class'=>'form-control','required'))}}
    	
		{{Form::label('featured_image','Upload Featured Image')}}
    	{{Form::file('featured_image')}}

    	{{Form::submit('create',array('class'=>'btn btn-success btn-lg btn-block','style'=>'margin-top:20px;'))}}
	{!! Form::close() !!}

@endsection
@extends('main')

@section('title')

@section('content')

<div class="row">
	<div class="col-md-10">
		<h1>Details</h1>
	</div>

	<div class="col-md-2">
		<a href="{{route('sample_data.create')}}" class="btn btn-lg btn-block btn-primary btn-h1-spacing">Create Details</a>
	</div>
	<div class="col-md-12">
		<hr>
	</div>
</div>

<div class="row">
	<div class="col-md-8">
		<table class="table">
			<thead>
				<th>#</th>
				<th>First Name</th>
				<th>NHIF Number</th>
				<th>Image</th>
			</thead>

			<tbody>
				@foreach($sampleData as $sample_data)
				<tr>
					<th>{{$sample_data ->id}}
					</th>
					<td>{{$sample_data->first_name }}
					</td>

					<td>{{$sample_data->NHIF_number}}
					</td>
					<td>{{$sample_data->image}}
					</td>

					<td><a href="{{route('sample_data.show',$sample_data ?? ''->id)}}" class="btn btn-default btn-sm">View</a></td>
					<td><a href="{{route('sample_data.edit',$sample_data ?? ''->id)}}" class="btn btn-default btn-sm">Edit</a></td>
				</tr>
				@endforeach
			</tbody>
		</table>
		<div class="text-center">
		
		</div>
	</div>
</div>
@endsection
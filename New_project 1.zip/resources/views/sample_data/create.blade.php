@extends('main')

@section('title')

@section('stylesheets')

	{!!Html::style('css/parsley.css')!!}

@endsection

@section('content')

	<div class="row">
	<div class="col-md-8 col-md-offset-2">
		<h1>Enter Details</h1>
		<hr>
</div>
</div>
	{!! Form::open(array('route' => 'sample_data.store','data-parsley-validate'=>'','files'=>true)) !!}
    	  	
		{{Form::label('first_name'),('First Name')}}
		{{Form::text('First Name',null,array('class'=>'form-control','required'))}}

		{{Form::label('NHIF_number'),('NHIF Number')}}
		{{Form::text('NHIF Number',null,array('class'=>'form-control','required'))}}
    	
		{{Form::label('featured_image','Upload Featured Image')}}
    	{{Form::file('featured_image')}}

    	{{Form::submit('Create',array('class'=>'btn btn-success btn-lg btn-block','style'=>'margin-top:20px;'))}}
	{!! Form::close() !!}

@endsection
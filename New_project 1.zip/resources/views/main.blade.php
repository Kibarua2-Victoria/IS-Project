<!DOCTYPE html>
<html>
<head>
	@yield('title')
	@include('partials._head')
</head>
<body>
	@include('partials._nav')
	<div class="container">
		@include('partials._messages')
		
		@yield('content')
	</div> <!--end of the container-->
	@include('partials._javascript')

	@yield('scripts')
</body>
</html>
@extends('main')

@section('content')
        <div class="row">
            <div class="col-md-12">
                <h1>Contact Us</h1>
                <hr>
                <form>
                    <div class="form-group">
                        <label name="subject">Subject</label>
                        <input type="text" name="subject" class="form-control">
                    </div>

                    <div class="form-group">
                        <label name="Message">Message</label>
                        <input type="text" name="subject" class="form-control">
                    </div>

                    <input type="submit" name="Send" class="btn btn-success">
                </form>
            </div>
        </div>
@endsection

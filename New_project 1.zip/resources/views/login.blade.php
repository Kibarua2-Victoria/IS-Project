<!DOCTYPE html>
<html>
<head>
	<title>LOGIN FORM</title>
</head>
<body>
	<br/>
	<div class="container box">
		<h1 align="center">Login</h1>

	@if(count($errors)>0)
		<div class="alert alert-danger">
			<ul>
				@foreach($errors->all()as $error)
					<li>{{$error}}</li>
				@endforeach
			</ul>
		</div>
	@endif
	</div>
		<form method="post" action="">
			{{csrf_field()}}
		<div class="form-group">
			<label>Enter Email</label>
			<input type="email" name="email" class="form-control"/>
		</div>
		<div class="form-group">
			<label>Enter Password</label>
			<input type="password" name="password" class="form-control"/>
		</div>
		<div class="form-group">
			<input type="submit" name="login" class="btn btn-primary" value="Login"/>
		</div>
		</form>
	</div>
</body>
</html>
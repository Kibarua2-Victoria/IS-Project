@extends('main')

@section('content')
<div class="row">
  <div class="col-md-12">
    <h1>About Us</h1>
    <p>We value integrity and transparency</p>
  </div>
</div>

 @endsection 

    